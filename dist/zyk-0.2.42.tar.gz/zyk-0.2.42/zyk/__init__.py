from zyk.lms.core.main import LM

__all__ = ["LM"]
