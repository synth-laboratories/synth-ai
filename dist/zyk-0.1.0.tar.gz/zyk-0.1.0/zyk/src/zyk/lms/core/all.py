from zyk.src.zyk.lms.vendors.core.openai_api import OpenAIPrivate
from zyk.src.zyk.lms.vendors.core.openai_api import OpenAIStructuredOutputClient
from typing import Any

class OpenAIClient(OpenAIPrivate):
    def __init__(self):
        super().__init__()

class AnthropicClient:
    pass