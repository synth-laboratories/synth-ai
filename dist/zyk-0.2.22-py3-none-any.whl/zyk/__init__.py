from zyk.src.lms.core.main import LM

__all__ = ["LM"]
