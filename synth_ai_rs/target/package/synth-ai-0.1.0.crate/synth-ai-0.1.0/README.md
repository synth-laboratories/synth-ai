# synth-ai

Rust SDK for [Synth AI](https://usesynth.ai) - serverless post-training APIs.

## Status

This crate is under active development. For the full-featured SDK, see the [Python package](https://pypi.org/project/synth-ai/).

## Links

- [Documentation](https://docs.usesynth.ai)
- [GitHub](https://github.com/synth-laboratories/synth-ai)
- [Discord](https://discord.gg/VKxZqUhZ)
